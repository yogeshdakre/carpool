import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { DatePipe } from '@angular/common';
import { DatePickerModule } from './common/directives/datepicker/datepicker.module';
import { DatepickerDemoComponent } from './datepicker-demo/datepicker-demo.component';


@NgModule({
    declarations: [
        AppComponent,
        DatepickerDemoComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DatePickerModule
    ],
    entryComponents: [
    ],
    providers: [
        DatePipe
    ],
    exports: [
        AppComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule {}

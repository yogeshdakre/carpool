import { IDate } from './date.interface';

export interface DateRange {
    begin: IDate;
    end: IDate;
}

export interface CalendarYear {
    year: number;
    currYear: boolean;
    selected: boolean;
    disabled: boolean;
}

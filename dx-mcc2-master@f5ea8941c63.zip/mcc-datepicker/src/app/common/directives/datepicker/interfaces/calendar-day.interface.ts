import { IDate } from './date.interface';
import { MarkedDate } from './marked-date.interface';

export interface CalendarDay {
    dateObj: IDate;
    cmo: number;
    currDay: boolean;
    disabled: boolean;
    markedDate: MarkedDate;
    highlight: boolean;
}

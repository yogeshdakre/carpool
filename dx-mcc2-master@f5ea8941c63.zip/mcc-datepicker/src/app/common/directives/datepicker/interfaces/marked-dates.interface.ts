import { IDate } from './date.interface';

export interface MarkedDates {
    dates: Array<IDate>;
    color: string;
}

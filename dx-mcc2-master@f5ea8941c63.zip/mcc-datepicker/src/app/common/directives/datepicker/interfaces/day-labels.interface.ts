export interface DayLabels {
    [day: string]: string;
}

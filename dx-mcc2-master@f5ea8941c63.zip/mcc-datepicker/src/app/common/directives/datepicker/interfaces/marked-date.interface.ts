export interface MarkedDate {
    marked: boolean;
    color: string;
}

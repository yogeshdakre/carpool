export interface CalendarMonth {
    nbr: number;
    name: string;
    currMonth: boolean;
    selected: boolean;
    disabled: boolean;
}

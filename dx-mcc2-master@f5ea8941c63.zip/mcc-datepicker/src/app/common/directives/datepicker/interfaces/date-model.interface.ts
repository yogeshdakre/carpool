import { IDate } from './date.interface';

export interface DateModel {
    date: IDate;
    jsdate: Date;
    formatted: string;
    epoc: number;
}

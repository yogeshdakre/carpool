import { Weekday } from './weekday.interface';

export interface CalendarViewChanged {
    year: number;
    month: number;
    first: Weekday;
    last: Weekday;
}

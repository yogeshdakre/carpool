import { EventEmitter } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { LocalizationModule } from 'angular-l10n';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IDate, Month, CalendarDay, CalendarMonth, CalendarYear, Week, DpOptions } from './interfaces/index';
import { DatePickerComponent } from './datepicker.component';
import { UtilService } from './services/datepicker.service';
import { Observable } from 'rxjs/Rx';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

const opts: any = { 'dayLabels' : {
    'su': 'Sun', 'mo': 'Mon', 'tu': 'Tue', 'we': 'Wed', 'th': 'Thu', 'fr': 'Fri', 'sa': 'Sat' },
    'monthLabels' : {
        '1': 'Jan', '2': 'Feb', '3': 'Mar', '4': 'Apr', '5': 'May', '6': 'Jun', '7': 'Jul',
        '8': 'Aug', '9': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec'
    }, 'monthFullLabels' :
    { '1': 'January', '2': 'February', '3': 'March', '4': 'April', '5': 'May', '6': 'June', '7': 'July',
    '8': 'August', '9': 'September', '10': 'October', '11': 'November', '12': 'December'
},
'dateFormat': 'mmm dd, yyyy', 'showTodayBtn': false, 'todayBtnTxt': 'Today', 'showNxtPrvDtOnCurrMon': false,
'firstDayOfWeek': 'su', 'satHighlight': true, 'sunHighlight': true, 'highlightDates': [],
'markCurrentDay': true, 'markCurrentMonth': true, 'markCurrentYear': true, 'monthSelector': true,
'yearSelector': true, 'disableHeaderButtons': true, 'showWeekNumbers': false, 'selectorHeight': '280px',
'selectorWidth': '275px', 'disableUntil': {'year': 2016, 'month': 11, 'day': 30},
'disableSince': {'year': 2017, 'month': 12, 'day': 23},
'disableDates': [], 'enableDates': [], 'markDates': [], 'markWeekends': {}, 'disableDateRanges': [],
'disableWeekends': false, 'alignSelectorRight': false, 'openSelectorTopOfInput': false,
'closeSelectorOnDateSelect': true, 'minYear': 1100, 'maxYear': 9100, 'showSelectorArrow': true,
'ariaLabelPrevMonth': 'Previous Month', 'ariaLabelNextMonth': 'Next Month',
'ariaLabelPrevYear': 'Previous Year', 'ariaLabelNextYear': 'Next Year', 'alignBottom': true,
'alignRight': false, 'alignTop': false, 'alignLeft': false, 'disableInput': true };

describe('DatePickerComponent', () => {

    let component: DatePickerComponent;
    let fixture: ComponentFixture<DatePickerComponent>;
    let utilService: UtilService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [DatePickerComponent],
            imports: [
                HttpClientModule
            ],
            providers: [
                UtilService
            ]
        });
        TestBed.overrideComponent(DatePickerComponent, { set: { template: '' } });
        fixture = TestBed.createComponent(DatePickerComponent);
        component = fixture.componentInstance;
        utilService = TestBed.get(UtilService);
        fixture.detectChanges();
    }));

    it('should create component', () => expect(component).toBeDefined());

    it('Should initialize datepicker', () => {

        const defaultMonth = undefined;
        const inputValue = '';
        const inputHeight = 44;
        const dc = function (dm, close) {};
        const cvc = function (temp) {};
        const cbe = function () {};
        component.initialize(opts, defaultMonth, inputValue, inputHeight, dc, cvc, cbe);
        expect(opts).toBeDefined();
    });
    it('Should call setCalendarView', () => {
        spyOn(component, 'setVisibleMonth');
        const date = {day: 3, month: 1, year: 2018};
        const monthFullLabels = {1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May',
         6: 'June', 7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'};
        component.setCalendarView(date);
        expect(component.setVisibleMonth).toHaveBeenCalled();
    });
    it('Should call resetMonthYearSelect', () => {
        component.resetMonthYearSelect();
        expect(component.setVisibleMonth).not.toBeNull();
    });
    it('should perform on month clicked', () => {
        component.opts = opts;
        const event = { isTrusted: true, screenX: 148, screenY: 170, clientX: 148, clientY: 104 };
        component.onSelectMonthClicked(event);
        expect(component.selectYear).toBeFalsy();
    });
    xit('should perform on year cell clicked', () => {
        spyOn(component, 'generateCalendar');
        component.opts = opts;
        const year = {year: 2018, currYear: true, selected: true, disabled: false};
        component.onYearCellClicked(year);
        expect(component.selectYear).toBeFalsy();
    });
    it('should perform on generate years function', () => {
        component.opts = opts;
        const year = 2018;
        component.generateYears(year);
        expect(component.nextYearsDisabled).toBeDefined();
    });
    it('should perform on previous month clicked', () => {
        component.calendarViewChanged = function() { return; };
        spyOn(component, 'calendarViewChanged');
        component.opts = opts;
        component.onPrevMonth();
        expect(component.visibleMonth).toBeDefined();
    });
    it('should perform on next month clicked', () => {
        component.calendarViewChanged = function() { return; };
        spyOn(component, 'calendarViewChanged');
        component.opts = opts;
        component.onNextMonth();
        expect(component.visibleMonth).toBeDefined();
    });
    it('should perform on prev year clicked', () => {
        component.calendarViewChanged = function() { return; };
        spyOn(component, 'calendarViewChanged');
        component.opts = opts;
        component.onPrevYear();
        expect(component.visibleMonth).toBeDefined();
    });
    it('should perform on next year clicked', () => {
        component.calendarViewChanged = function() { return; };
        spyOn(component, 'calendarViewChanged');
        component.opts = opts;
        component.onNextYear();
        expect(component.visibleMonth).toBeDefined();
    });
    it('should perform on today clicked', () => {
        component.calendarViewChanged = function() { return; };
        component.dateChanged = function() { return; };
        spyOn(component, 'calendarViewChanged');
        spyOn(component, 'dateChanged');
        component.opts = opts;
        component.onTodayClicked();
        expect(component.visibleMonth).toBeDefined();
    });
});


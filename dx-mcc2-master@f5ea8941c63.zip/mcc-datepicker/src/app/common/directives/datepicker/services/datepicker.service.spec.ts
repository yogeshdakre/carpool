import { HttpClient, HttpClientModule } from '@angular/common/http';
import { localeConfig } from '../../../../common/locale.config';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UtilService } from '../services/datepicker.service';
import { Observable } from 'rxjs/Rx';

describe('DatePickerService', () => {

    let utilService: UtilService;
    let httpClient: HttpClient;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientModule
            ],
            providers: [
                UtilService
            ]
        });
        utilService = TestBed.get(UtilService);
        httpClient = TestBed.get(HttpClient);
    });

    it('should create the component', () => {
        expect(utilService).toBeDefined();
    });

    it('should call isDateValid', () => {
        spyOn(utilService, 'isMonthLabelValid');
        const dateStr = '';
        const dateFormat = 'mmm dd, yyyy';
        const minYear =  1100;
        const maxYear = 9100;
        const disableUntil = {year: 2016, month: 12, day: 31};
        const disableSince = {year: 2018, month: 1, day: 5};
        const disableWeekends = false;
        const disableDates = [];
        const disableDateRanges = [];
        const monthLabels = { 1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 7: 'Jul',
        8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'};
        const enableDates = [];
        utilService.isDateValid(dateStr, dateFormat, minYear, maxYear, disableUntil, disableSince, disableWeekends,
            disableDates, disableDateRanges, monthLabels, enableDates);
        expect(utilService.isMonthLabelValid).toHaveBeenCalled();
    });

    it('should call isDateValid isMonthStr condition true', () => {
        spyOn(utilService, 'isMonthLabelValid').and.returnValue(1);
        const dateStr = '';
        const dateFormat = 'mmm dd, yyyy';
        const minYear =  1100;
        const maxYear = 9100;
        const disableUntil = {year: 2016, month: 12, day: 31};
        const disableSince = {year: 2018, month: 1, day: 5};
        const disableWeekends = false;
        const disableDates = [];
        const disableDateRanges = [];
        const monthLabels = { 1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 7: 'Jul',
        8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'};
        const enableDates = [];
        utilService.isDateValid(dateStr, dateFormat, minYear, maxYear, disableUntil, disableSince, disableWeekends,
            disableDates, disableDateRanges, monthLabels, enableDates);
        expect(utilService.isMonthLabelValid).toHaveBeenCalled();
    });

    it('should call on day month & year not equal to -1', () => {
        spyOn(utilService, 'parseDatePartNumber');
        const dateStr = 'Jan 02, 2018';
        const dateFormat = 'mmm dd, yyyy';
        const minYear =  1100;
        const maxYear = 9100;
        const disableUntil = {year: 2016, month: 12, day: 31};
        const disableSince = {year: 2018, month: 1, day: 5};
        const disableWeekends = false;
        const disableDates = [];
        const disableDateRanges = [];
        const monthLabels = { 1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 7: 'Jul',
        8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'};
        const enableDates = [];
        utilService.isDateValid(dateStr, dateFormat, minYear, maxYear, disableUntil, disableSince, disableWeekends,
            disableDates, disableDateRanges, monthLabels, enableDates);
        expect(utilService.parseDatePartNumber).toHaveBeenCalled();
    });

    it('should call isYearLabelValid', () => {
        const yearLabel = 2018;
        const minYear =  1100;
        const maxYear = 9100;
        utilService.isYearLabelValid(yearLabel, minYear, maxYear);
    });

    it('should call parseDatePartNumber', () => {
        const dateStr = 'Jan 02, 2018';
        const dateFormat = 'mmm dd, yyyy';
        const datePart = 'dd';
        utilService.parseDatePartNumber(dateFormat, dateStr, datePart);
    });

    it('should call parseDefaultMonth', () => {
        const month = '04-01-2018';
        utilService.parseDefaultMonth(month);
    });

    it('should call getWeekNumber', () => {
        const date = {year: 2018, month: 1, day: 4};
        utilService.getWeekNumber(date);
    });

    it('should call isMarkedDate', () => {
        const date = {year: 2017, month: 12, day: 31};
        const markDates: any = [{dates: [2, 3, 4], color: 'red'}, {dates: [2, 3, 4], color: 'red'}];
        const markWeekends: any = {marked: true, color: 'red'};
        utilService.isMarkedDate(date, markDates, markWeekends);
    });

    it('should call isHighlightedDate', () => {
        const date = {year: 2017, month: 12, day: 31};
        const sunHighlight = true;
        const satHighlight = true;
        const highlightDates: any = [{year: 2017, month: 12, day: 31}, {year: 2018, month: 1, day: 1}];
        utilService.isHighlightedDate(date, sunHighlight, satHighlight, highlightDates);
    });
});

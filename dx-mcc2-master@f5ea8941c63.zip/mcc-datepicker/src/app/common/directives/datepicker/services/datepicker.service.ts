import { Injectable } from '@angular/core';
import { DateModel } from '../interfaces/date-model.interface';
import { IDate } from '../interfaces/date.interface';
import { DateRange } from '../interfaces/date-range.interface';
import { Month } from '../interfaces/month.interface';
import { MonthLabels } from '../interfaces/month-labels.interface';
import { MarkedDates } from '../interfaces/marked-dates.interface';
import { MarkedDate } from '../interfaces/marked-date.interface';

const M = 'm';
const MM = 'mm';
const MMM = 'mmm';
const DD = 'dd';
const YYYY = 'yyyy';

@Injectable()
export class UtilService {
    isDateValid(dateStr: string, dateFormat: string, minYear: number, maxYear: number,
                disableUntil: IDate, disableSince: IDate, disableWeekends: boolean, disableDates: Array<IDate>,
                disableDateRanges: Array<DateRange>, monthLabels: MonthLabels, enableDates: Array<IDate>): IDate {
        const returnDate: IDate = {day: 0, month: 0, year: 0};
        const daysInMonth: Array<number> = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        const isMonthStr: boolean = dateFormat.indexOf(MMM) !== -1;
        const separators: Array<string> = dateFormat.match(/[^(dmy)]{1,}/g);

        const month: number = isMonthStr ? this.parseDatePartMonthName(dateFormat, dateStr, MMM, monthLabels)
            : this.parseDatePartNumber(dateFormat, dateStr, MM);
        if (isMonthStr && monthLabels[month]) {
            dateFormat = this.changeDateFormat(dateFormat, monthLabels[month].length);
        }
        if (dateStr.length !== dateFormat.length) {
            return returnDate;
        }
        if (dateFormat.indexOf(separators[0]) !== dateStr.indexOf(separators[0]) ||
            dateFormat.lastIndexOf(separators[1]) !== dateStr.lastIndexOf(separators[1])) {
            return returnDate;
        }
        const day: number = this.parseDatePartNumber(dateFormat, dateStr, DD);
        const year: number = this.parseDatePartNumber(dateFormat, dateStr, YYYY);

        if (month !== -1 && day !== -1 && year !== -1) {
            if (year < minYear || year > maxYear || month < 1 || month > 12) {
                return returnDate;
            }

            const date: IDate = {year: year, month: month, day: day};

            if (this.isDisabledDate(date, minYear, maxYear, disableUntil, disableSince, disableWeekends,
                    disableDates, disableDateRanges, enableDates)) {
                return returnDate;
            }

            if (year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)) {
                daysInMonth[1] = 29;
            }

            if (day < 1 || day > daysInMonth[month - 1]) {
                return returnDate;
            }

            // Valid date
            return date;
        }
        return returnDate;
    }

    changeDateFormat(dateFormat: string, len: number): string {
        let mp = '';
        for (let i = 0; i < len; i++) {
            mp += M;
        }
        return dateFormat.replace(MMM, mp);
    }

    isMonthLabelValid(monthLabel: string, monthLabels: MonthLabels): number {
        for (let key = 1; key <= 12; key++) {
            if (monthLabel.toLowerCase() === monthLabels[key].toLowerCase()) {
                return key;
            }
        }
        return -1;
    }

    isYearLabelValid(yearLabel: number, minYear: number, maxYear: number): number {
        if (yearLabel >= minYear && yearLabel <= maxYear) {
            return yearLabel;
        }
        return -1;
    }

    parseDatePartNumber(dateFormat: string, dateString: string, datePart: string): number {
        const pos: number = dateFormat.indexOf(datePart);
        if (pos !== -1) {
            const value: string = dateString.substring(pos, pos + datePart.length);
            if (!/^\d+$/.test(value)) {
                return -1;
            }
            return parseInt(value, 10);
        }
        return -1;
    }

    parseDatePartMonthName(dateFormat: string, dateString: string, datePart: string, monthLabels: MonthLabels): number {
        let monthLabel = '';
        const start: number = dateFormat.indexOf(datePart);
        if (dateFormat.substr(dateFormat.length - 3) === MMM) {
            monthLabel = dateString.substring(start);
        } else {
            const end: number = dateString.indexOf(dateFormat.charAt(start + datePart.length), start);
            monthLabel = dateString.substring(start, end);
        }
        return this.isMonthLabelValid(monthLabel, monthLabels);
    }

    parseDefaultMonth(monthString: string): Month {
        const month: Month = {monthTxt: '', monthNbr: 0, year: 0};
        if (monthString !== '') {
            const split = monthString.split(monthString.match(/[^0-9]/)[0]);
            month.monthNbr = split[0].length === 2 ? parseInt(split[0], 10) : parseInt(split[1], 10);
            month.year = split[0].length === 2 ? parseInt(split[1], 10) : parseInt(split[0], 10);
        }
        return month;
    }

    isDisabledDate(date: IDate, minYear: number, maxYear: number, disableUntil: IDate, disableSince: IDate,
                   disableWeekends: boolean, disableDates: Array<IDate>, disableDateRanges: Array<DateRange>,
                   enableDates: Array<IDate>): boolean {
        for (const d of enableDates) {
            if (d.year === date.year && d.month === date.month && d.day === date.day) {
                return false;
            }
        }

        if (date.year < minYear && date.month === 12 || date.year > maxYear && date.month === 1) {
            return true;
        }

        const dateMs: number = this.getTimeInMilliseconds(date);
        if (this.isInitializedDate(disableUntil) && dateMs <= this.getTimeInMilliseconds(disableUntil)) {
            return true;
        }

        if (this.isInitializedDate(disableSince) && dateMs >= this.getTimeInMilliseconds(disableSince)) {
            return true;
        }

        if (disableWeekends) {
            const dayNbr = this.getDayNumber(date);
            if (dayNbr === 0 || dayNbr === 6) {
                return true;
            }
        }

        for (const d of disableDates) {
            if (d.year === date.year && d.month === date.month && d.day === date.day) {
                return true;
            }
        }

        for (const d of disableDateRanges) {
            if (this.isInitializedDate(d.begin) && this.isInitializedDate(d.end) && dateMs >=
                this.getTimeInMilliseconds(d.begin) && dateMs <= this.getTimeInMilliseconds(d.end)) {
                return true;
            }
        }
        return false;
    }

    isMarkedDate(date: IDate, markedDates: Array<MarkedDates>, markWeekends: MarkedDate): MarkedDate {
        for (const md of markedDates) {
            for (const d of md.dates) {
                if (d.year === date.year && d.month === date.month && d.day === date.day) {
                    return {marked: true, color: md.color};
                }
            }
        }
        if (markWeekends && markWeekends.marked) {
            const dayNbr = this.getDayNumber(date);
            if (dayNbr === 0 || dayNbr === 6) {
                return {marked: true, color: markWeekends.color};
            }
        }
        return {marked: false, color: ''};
    }

    isHighlightedDate(date: IDate, sunHighlight: boolean, satHighlight: boolean, highlightDates: Array<IDate>): boolean {
        const dayNbr: number = this.getDayNumber(date);
        if (sunHighlight && dayNbr === 0 || satHighlight && dayNbr === 6) {
            return true;
        }
        for (const d of highlightDates) {
            if (d.year === date.year && d.month === date.month && d.day === date.day) {
                return true;
            }
        }
        return false;
    }

    getWeekNumber(date: IDate): number {
        const d: Date = new Date(date.year, date.month - 1, date.day, 0, 0, 0, 0);
        d.setDate(d.getDate() + (d.getDay() === 0 ? -3 : 4 - d.getDay()));
        return Math.round(((d.getTime() - new Date(d.getFullYear(), 0, 4).getTime()) / 86400000) / 7) + 1;
    }

    isMonthDisabledByDisableUntil(date: IDate, disableUntil: IDate): boolean {
        return this.isInitializedDate(disableUntil) && this.getTimeInMilliseconds(date) <= this.getTimeInMilliseconds(disableUntil);
    }

    isMonthDisabledByDisableSince(date: IDate, disableSince: IDate): boolean {
        return this.isInitializedDate(disableSince) && this.getTimeInMilliseconds(date) >= this.getTimeInMilliseconds(disableSince);
    }

    getDateModel(date: IDate, dateFormat: string, monthLabels: MonthLabels): DateModel {
        return {date: date, jsdate: this.getDate(date), formatted: this.formatDate(date, dateFormat, monthLabels),
            epoc: Math.round(this.getTimeInMilliseconds(date) / 1000.0)};
    }

    formatDate(date: IDate, dateFormat: string, monthLabels: MonthLabels): string {
        const formatted: string = dateFormat.replace(YYYY, String(date.year)).replace(DD, this.preZero(date.day));
        return dateFormat.indexOf(MMM) !== -1 ? formatted.replace(MMM, monthLabels[date.month])
            : formatted.replace(MM, this.preZero(date.month));
    }

    preZero(val: number): string {
        return val < 10 ? '0' + val : String(val);
    }

    isInitializedDate(date: IDate): boolean {
        return date.year !== 0 && date.month !== 0 && date.day !== 0;
    }

    getTimeInMilliseconds(date: IDate): number {
        return this.getDate(date).getTime();
    }

    getDate(date: IDate): Date {
        return new Date(date.year, date.month - 1, date.day, 0, 0, 0, 0);
    }

    getDayNumber(date: IDate): number {
        const d: Date = new Date(date.year, date.month - 1, date.day, 0, 0, 0, 0);
        return d.getDay();
    }
}

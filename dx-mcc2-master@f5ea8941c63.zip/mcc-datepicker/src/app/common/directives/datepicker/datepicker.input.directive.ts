import {
    Directive, Input, ComponentRef, ElementRef, ViewContainerRef, Renderer, ChangeDetectorRef,
    ComponentFactoryResolver, forwardRef, EventEmitter, Output, SimpleChanges, OnChanges, HostListener
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { IDate, DpOptions, DateModel, CalendarViewChanged, InputFieldChanged } from './interfaces/index';
import { DatePickerComponent } from './datepicker.component';
import { UtilService } from './services/datepicker.service';
import { DatePickerConfig } from './services/date-picker.config';
import { CalToggle } from './enums/cal-toggle.enum';
import { Year } from './enums/year.enum';
import { KeyCode } from './enums/key-code.enum';

const DP_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DatePickerDirective),
    multi: true
};

@Directive({
    selector: '[saDatePicker]',
    exportAs: 'sa-date-picker',
    providers: [UtilService, DP_VALUE_ACCESSOR, DatePickerConfig]
})
export class DatePickerDirective implements OnChanges, ControlValueAccessor {
    @Input() options: DpOptions;
    @Input() defaultMonth: string;
    @Input() isDisabled: boolean;

    @Output() dateChanged: EventEmitter<DateModel> = new EventEmitter<DateModel>();
    @Output() inputFieldChanged: EventEmitter<InputFieldChanged> = new EventEmitter<InputFieldChanged>();
    @Output() calendarViewChanged: EventEmitter<CalendarViewChanged> = new EventEmitter<CalendarViewChanged>();
    @Output() calendarToggle: EventEmitter<number> = new EventEmitter<number>();

    private cRef: ComponentRef<DatePickerComponent> = null;
    private inputText = '';
    private preventClose = false;

    private opts: DpOptions;

    onChangeCb: (_: any) => void = () => { };
    onTouchedCb: () => void = () => { };

    constructor(private utilService: UtilService,
                private vcRef: ViewContainerRef,
                private cfr: ComponentFactoryResolver,
                private renderer: Renderer,
                private cdr: ChangeDetectorRef,
                private elem: ElementRef,
                private config: DatePickerConfig) {
        this.opts = Object.assign({}, config);
        this.parseOptions(config, this.isDisabled);
    }

    @HostListener('keyup', ['$event']) onKeyUp(evt: KeyboardEvent) {
        if (evt.keyCode === KeyCode.leftArrow || evt.keyCode === KeyCode.rightArrow) {
            return;
        } else if (evt.keyCode === KeyCode.esc) {
            this.closeSelector(CalToggle.CloseByEsc);
        } else {
            const date: IDate = this.utilService.isDateValid(this.elem.nativeElement.value, this.opts.dateFormat,
                this.opts.minYear, this.opts.maxYear, this.opts.disableUntil, this.opts.disableSince, this.opts.disableWeekends,
                this.opts.disableDates, this.opts.disableDateRanges, this.opts.monthLabels, this.opts.enableDates);
            if (this.utilService.isInitializedDate(date)) {
                const dateModel: DateModel = this.utilService.getDateModel(date, this.opts.dateFormat, this.opts.monthLabels);
                this.emitDateChanged(dateModel);
                this.updateModel(dateModel);
                this.emitInputFieldChanged(dateModel.formatted, true);
                if (this.opts.closeSelectorOnDateSelect) {
                    this.closeSelector(CalToggle.CloseByDateSel);
                } else if (this.cRef !== null) {
                    this.cRef.instance.setCalendarView(date);
                }
            } else {
                if (this.inputText !== this.elem.nativeElement.value) {
                    if (this.elem.nativeElement.value === '') {
                        this.clearDate();
                    } else {
                        this.onChangeCb(null);
                        this.emitInputFieldChanged(this.elem.nativeElement.value, false);
                    }
                }
            }
            this.inputText = this.elem.nativeElement.value;
        }
    }

    @HostListener('blur') onBlur() {
        this.onTouchedCb();
    }

    @HostListener('document:click', ['$event']) onClick(evt: MouseEvent) {
        if (!this.preventClose && evt.target && this.cRef !== null && this.elem.nativeElement !== evt.target &&
            !this.cRef.location.nativeElement.contains(evt.target)) {
            this.closeSelector(CalToggle.CloseByOutClick);
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.hasOwnProperty('options')) {
            this.parseOptions(changes['options'].currentValue, this.isDisabled);
        }

        if (changes.hasOwnProperty('isDisabled')) {
            this.parseOptions(this.opts, changes['isDisabled'].currentValue);
        }

        if (changes.hasOwnProperty('defaultMonth')) {
            let dm: any = changes['defaultMonth'].currentValue;
            if (typeof dm === 'object') {
                dm = dm.defMonth;
            }
            this.defaultMonth = dm;
        }
    }

    public parseOptions(opts: DpOptions, isDisabled: boolean): void {
        if (opts !== undefined) {
            Object.keys(opts).forEach((k) => {
                (<DpOptions>this.opts)[k] = opts[k];
            });
        }
        if (this.opts.minYear < Year.min) {
            this.opts.minYear = Year.min;
        }
        if (this.opts.maxYear > Year.max) {
            this.opts.maxYear = Year.max;
        }
        if (this.opts.disableInput || isDisabled) {
            this.elem.nativeElement.setAttribute('readonly', '');
            if (!isDisabled) {
                this.elem.nativeElement.style.backgroundColor = 'white';
                this.elem.nativeElement.style.cursor = 'inherit';
                this.elem.nativeElement.style.color = '#555';
            } else {
                this.elem.nativeElement.style.cursor = 'not-allowed';
                this.elem.nativeElement.style.color = '#bfbbb3';
                this.elem.nativeElement.style.backgroundColor = '#f7f7f7';
            }
        }
    }

    public writeValue(value: Object): void {
        if (value && (value['date'] || value['jsdate'])) {
            const formatted: string = this.utilService.formatDate(value['date'] ? value['date'] :
                this.jsDateToMyDate(value['jsdate']), this.opts.dateFormat, this.opts.monthLabels);
            this.setInputValue(formatted);
            const date: IDate = this.utilService.isDateValid(formatted, this.opts.dateFormat, this.opts.minYear,
                this.opts.maxYear, this.opts.disableUntil, this.opts.disableSince, this.opts.disableWeekends,
                this.opts.disableDates, this.opts.disableDateRanges, this.opts.monthLabels, this.opts.enableDates);
            this.emitInputFieldChanged(formatted, this.utilService.isInitializedDate(date));
        } else if (value === null || value === '') {
            this.setInputValue('');
            this.emitInputFieldChanged('', false);
        }
    }

    public registerOnChange(fn: any): void {
        this.onChangeCb = fn;
    }

    public registerOnTouched(fn: any): void {
        this.onTouchedCb = fn;
    }

    public openCalendar(): void {
        if (!this.isDisabled) {
            this.preventClose = true;
            this.cdr.detectChanges();
            if (this.cRef === null) {
                const cf = this.cfr.resolveComponentFactory(DatePickerComponent);
                this.cRef = this.vcRef.createComponent(cf);
                this.cRef.instance.initialize(
                    this.opts,
                    this.defaultMonth,
                    this.elem.nativeElement.value,
                    this.elem.nativeElement.offsetHeight,
                    (dm: DateModel, close: boolean) => {
                        this.emitDateChanged(dm);
                        this.updateModel(dm);
                        if (close) {
                            this.closeSelector(CalToggle.CloseByDateSel);
                        }
                    },
                    (cvc: CalendarViewChanged) => {
                        this.emitCalendarChanged(cvc);
                    },
                    () => {
                        this.closeSelector(CalToggle.CloseByEsc);
                    }
                );
                this.emitCalendarToggle(CalToggle.Open);
            }
            setTimeout(() => {
                this.preventClose = false;
            }, 50);
        } else {
            return;
        }

    }

    public closeCalendar(): void {
        this.closeSelector(CalToggle.CloseByCalBtn);
    }

    public toggleCalendar(): void {
        if (this.cRef === null) {
            this.openCalendar();
        } else {
            this.closeSelector(CalToggle.CloseByCalBtn);
        }
    }

    public clearDate(): void {
        this.emitDateChanged({date: {year: 0, month: 0, day: 0}, jsdate: null, formatted: '', epoc: 0});
        this.emitInputFieldChanged('', false);
        this.onChangeCb(null);
        this.onTouchedCb();
        this.setInputValue('');
        this.closeSelector(CalToggle.CloseByCalBtn);
    }

    private closeSelector(reason: number): void {
        if (this.cRef !== null) {
            this.vcRef.remove(this.vcRef.indexOf(this.cRef.hostView));
            this.cRef = null;
            this.emitCalendarToggle(reason);
        }
    }

    private updateModel(model: DateModel): void {
        this.onChangeCb(model);
        this.onTouchedCb();
        this.setInputValue(model.formatted);
    }

    private setInputValue(value: string): void {
        this.inputText = value;
        this.renderer.setElementProperty(this.elem.nativeElement, 'value', value);
    }

    private emitDateChanged(dateModel: DateModel): void {
        this.dateChanged.emit(dateModel);
    }

    private emitInputFieldChanged(value: string, valid: boolean): void {
        this.inputFieldChanged.emit({value: value, dateFormat: this.opts.dateFormat, valid: valid});
    }

    private emitCalendarChanged(cvc: CalendarViewChanged) {
        this.calendarViewChanged.emit(cvc);
    }

    private emitCalendarToggle(reason: number): void {
        this.calendarToggle.emit(reason);
    }

    private jsDateToMyDate(date: Date): IDate {
        return {year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate()};
    }
}

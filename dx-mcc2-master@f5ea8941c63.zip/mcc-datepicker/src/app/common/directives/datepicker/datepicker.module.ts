import { ModuleWithProviders, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DatePickerComponent } from './datepicker.component';
import { DatePickerDirective } from './datepicker.input.directive';
import { FocusDirective } from './directives/date-picker.focus.directive';
import { DatePickerConfig } from './services/date-picker.config';

@NgModule({
    imports: [CommonModule, FormsModule],
    declarations: [DatePickerComponent, DatePickerDirective, FocusDirective],
    entryComponents: [DatePickerComponent],
    exports: [DatePickerComponent, DatePickerDirective, FocusDirective]
})
export class DatePickerModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: DatePickerModule,
            providers: [DatePickerConfig]
        };
    }
}

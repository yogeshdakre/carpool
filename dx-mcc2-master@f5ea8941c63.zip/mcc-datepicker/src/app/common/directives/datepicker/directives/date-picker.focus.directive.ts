import { Directive, ElementRef, Renderer, AfterViewInit, Input } from '@angular/core';

@Directive({
    selector: '[saDpfocus]'
})

export class FocusDirective implements AfterViewInit {
    @Input() saDpfocus: string;

    constructor(private el: ElementRef, private renderer: Renderer) {}

    // Focus to element: if dpfocus 0 = don't set focus, 1 = set only focus
    ngAfterViewInit() {
        if (this.saDpfocus === '0') {
            return;
        }
        this.renderer.invokeElementMethod(this.el.nativeElement, 'focus', []);
    }
}
